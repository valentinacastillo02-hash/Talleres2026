package App;

public class Alimento {

}
